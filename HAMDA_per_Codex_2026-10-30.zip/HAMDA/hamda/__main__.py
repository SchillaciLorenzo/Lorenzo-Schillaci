"""Consente l'avvio con ``python -m hamda``."""

from hamda.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
