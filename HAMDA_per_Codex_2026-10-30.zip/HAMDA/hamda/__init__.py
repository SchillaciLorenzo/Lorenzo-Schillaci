"""HAMDA: a hardware-independent, simulated haptic motor controller."""

__version__ = "0.1.0"
