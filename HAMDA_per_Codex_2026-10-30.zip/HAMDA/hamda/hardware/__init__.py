"""Output interfaces. This milestone includes simulation only."""
