"""Punto d'ingresso semplice, utilizzabile anche dall'editor Thonny."""

from hamda.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
