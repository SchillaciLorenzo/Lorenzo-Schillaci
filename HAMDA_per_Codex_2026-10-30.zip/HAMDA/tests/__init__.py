"""Test automatici del prototipo simulato HAMDA."""
